#!/usr/bin/env bash
# Builds and runs ManutenCar (MySQL + FastAPI + React/nginx) with Docker.
# Usage: ./run.sh            -> serves the app on port 80
#        PORT=8080 ./run.sh  -> serves the app on another port
# Re-running rebuilds the app with the latest code; the database is kept.
set -euo pipefail

cd "$(dirname "$0")"
PORT="${PORT:-80}"
SECRETS=backend/secrets
NET=manutencar

command -v docker >/dev/null || { echo "Docker is not installed." >&2; exit 1; }
command -v openssl >/dev/null || { echo "openssl is not installed." >&2; exit 1; }

# --- Secrets: generated once, reused on every run (backend/secrets is gitignored) ---
mkdir -p "$SECRETS"
if [ ! -f "$SECRETS/auth-private-key.pem" ]; then
  openssl genpkey -algorithm RSA -out "$SECRETS/auth-private-key.pem" -pkeyopt rsa_keygen_bits:2048
  openssl pkey -in "$SECRETS/auth-private-key.pem" -pubout -out "$SECRETS/auth-public-key.pem"
fi
if [ ! -f "$SECRETS/deploy.env" ]; then
  cat > "$SECRETS/deploy.env" <<EOF
MYSQL_ROOT_PASSWORD=$(openssl rand -hex 24)
MYSQL_PASSWORD=$(openssl rand -hex 24)
JWT_SECRET=$(openssl rand -hex 48)
EOF
  chmod 600 "$SECRETS/deploy.env"
fi
# shellcheck disable=SC1091
source "$SECRETS/deploy.env"

# --- Build images ---
docker build -t manutencar-api -f - backend <<'DOCKERFILE'
FROM python:3.12-slim
WORKDIR /srv
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app ./app
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
DOCKERFILE

docker build -t manutencar-web --build-arg VITE_AUTH_PUBLIC_KEY="$(cat "$SECRETS/auth-public-key.pem")" -f - . <<'DOCKERFILE'
FROM node:20-alpine AS build
WORKDIR /src
COPY package.json package-lock.json ./
RUN npm ci
COPY index.html tsconfig.json tsconfig.node.json vite.config.ts ./
COPY public ./public
COPY src ./src
ARG VITE_AUTH_PUBLIC_KEY
RUN VITE_AUTH_PUBLIC_KEY="$VITE_AUTH_PUBLIC_KEY" npm run build

FROM nginx:alpine
COPY --from=build /src/dist /usr/share/nginx/html
COPY <<'EOF' /etc/nginx/conf.d/default.conf
server {
  listen 80;
  root /usr/share/nginx/html;
  resolver 127.0.0.11 valid=10s;
  set $api http://manutencar-api:8000;
  location /api/ {
    proxy_pass $api;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
  location / {
    try_files $uri /index.html;
  }
}
EOF
DOCKERFILE

# --- Network + database (kept across runs) ---
docker network inspect "$NET" >/dev/null 2>&1 || docker network create "$NET"
if ! docker container inspect manutencar-db >/dev/null 2>&1; then
  docker run -d --name manutencar-db --network "$NET" --restart unless-stopped \
    -e MYSQL_ROOT_PASSWORD="$MYSQL_ROOT_PASSWORD" \
    -e MYSQL_DATABASE=manutencar -e MYSQL_USER=manutencar -e MYSQL_PASSWORD="$MYSQL_PASSWORD" \
    -v manutencar-db-data:/var/lib/mysql \
    mysql:8.4
else
  docker start manutencar-db >/dev/null
fi

echo "Waiting for MySQL..."
until docker exec manutencar-db mysqladmin ping -h 127.0.0.1 -uroot -p"$MYSQL_ROOT_PASSWORD" --silent >/dev/null 2>&1; do
  sleep 2
done

# --- App containers (recreated every run) ---
docker rm -f manutencar-api manutencar-web >/dev/null 2>&1 || true

docker run -d --name manutencar-api --network "$NET" --restart unless-stopped \
  -e DATABASE_URL="mysql+pymysql://manutencar:${MYSQL_PASSWORD}@manutencar-db:3306/manutencar" \
  -e JWT_SECRET="$JWT_SECRET" \
  -e AUTH_PRIVATE_KEY_PATH=/run/secrets/auth-private-key.pem \
  -v "$PWD/$SECRETS/auth-private-key.pem:/run/secrets/auth-private-key.pem:ro" \
  manutencar-api

docker run -d --name manutencar-web --network "$NET" --restart unless-stopped \
  -p "$PORT:80" \
  manutencar-web

echo
echo "ManutenCar is running on http://<your-server-ip>:$PORT"
echo "Logs: docker logs -f manutencar-api   |   Stop: docker rm -f manutencar-web manutencar-api manutencar-db"
